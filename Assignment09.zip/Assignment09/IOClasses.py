#------------------------------------#
# Title: IO Classes
# Desc: A Module for IO Classes
# Change Log: (Who, When, What)
# DBiesinger, 2030-Jan-01, Created File
# DBiesinger, 2030-Jan-02, Extended functionality to add tracks
# MMezistrano, 2020-Mar-26, Added code, completed todos, added comments
#------------------------------------#

if __name__ == '__main__':
    raise Exception('This file is not meant to run by itself')

import DataClasses as DC #uses alias
import ProcessingClasses as PC #also alias

class FileIO:
    """Processes data to and from file
    
    properties:
        
    methods:
        save_inventory(file_name, lst_inventory): -> None
        load_inventory(file_name): -> (a list of CD objects)
    
    """
    @staticmethod
    def save_inventory(file_name: str, lst_inventory: list) -> None:
        
        """
        
        Args:
            file_name(str): name of file that holds data.
            lst_inventory (list): list of CD objects.
        
        Returns:
            none.
        
        """
        file_name_CD = file_name[0]
        file_name_trk = file_name[1]
        
         # TODOne modify method to accept a list of file names.
        try:
            with open(file_name, 'w') as file:
                for disc in lst_inventory:
                    file.write(disc.get_record()) #writing using formatted method from DC method
            # TODOne add code to save track data to file
            with open(file_name_trk, 'w') as file:
                for disc in list_inventory:
                    tracks = disc.cd_tracks
                    disc_id = disc.cd_id
                    for trk in tracks:
                        if trk is not None: #makes sure there is data in track
                            record = '{},{}'.format(disc_id, trk.get_record()) #calls formatted track method from DC method
                            file.write(record)
        except Exception as e:
            print('There was a general error', e, e.__doc__, type(e), sep='\n')
    
    @staticmethod
    def load_inventory(file_name: str) -> list:
        """
        
        Args:
            file_name(str): name of file that holds data.
        
        Returns:
            list: list of CD objects..
        
        """
        lst_inventory = []
        # TODOne modify method to accept a list of file names
        file_name_CD = file_name[0]
        file_name_trk = file_name[1]
        try: 
            with open(file_name_CD, 'r') as file:
                for line in file:
                    data = line.strip().split(',')
                    row = DC.CD(data[0], data[1], data[2])
                    lst_inventory.append(row)
           # TODOne add code to load track data
           with open(file_name_trk, 'r') as file:
                for line in file:
                    data = line.strip().split(',')
                    cd = PC.DataProcessor.select_cd(lst_inventory, int(data[0]))
                    track = DC.Track(int((data[1]), data[2], data[3]) #track number cast as int, rest of track data is strings
                    cd.add_track(track)
        except Exception as e:
            print('There was a general error', e, e.__doc__, type(e), sep='\n')
        return lst_inventory

class ScreenIO:
    """Handling input/output"""
    
    @staticmethod
    def print_menu():
        """Displays a menu of choices to the user

        Args:
            None.

        Returns:
            None.
        """
        print('Menu\n\n[d] Display Current Inventory\n[a] Add CD\n[s] [c] Choose CD [s] Save Inventory to file\n[l] load Inventory from file\n[x] exit\n')

     @staticmethod
     def menu_choice():
        """Gets user input for menu selection, returns ValueError if choice not in menu.

        Args:
            None.

        Returns:
            choice (string): a lower case sting of the users input out of the choices l, a, i, d, s or x

        """
        choice = ' ' 
        while choice not in ['l', 'a', 'd', 'c', 's', 'x']:
            choice = input('Which operation would you like to perform? [l, a, i, d, s or x]: ').lower().strip()
        print()  #  space for layout
        return choice
    
    @staticmethod
    def print_cd_menu():
        """Displays sub menu of choices for CD to user
        
        Args:
            none
        
        Returns:
            none
        """
        
        print('CD Sub menu\n\n[a] Add track\n[d] Display cd details\n[r] Remove track\n[x] exit to Main Menu')
    
    @staticmethod
    def menu_cd_choice():
        """Gets user input for CD sub menu selection
        
        Args:
            none.
        
        Returns: 
            choice (string): a lower case string of user's input out of sub menu choices
        
        """
        
        choice = ''
        while choice not in ['a', 'd', 'r', 'x']:
            choice = input('Which operation would you like to perform? [a, d, r, or x]: ').lower().strip()
        print()
        return choice
    
    @staticmethod
    def show_inventory(table):
        """Displays current inventory table

        Args:
            table (list of CDObjects): 2D data structure (list of CDObjects) that holds the data during runtime.

        Returns:
            None.
            
        """
        print('======= The Current Inventory: =======')
        print('ID\tCD Title (by: Artist)\n')
        for row in table:
            print(row.print_neat()) #cycling through each CD object and print_neat shows the individual values of each object
        print('======================================')
    
   @staticmethod
   def show_tracks(cd):
       """Displays tracks on a CD
       
       Args:
           cd (CD): a CD object
       Returns:
           none.
       """
       
       print('===Current CD ===')
       print(cd)
       print('==================)
       print(cd.get_tracks()) #formatted track info from DC method
       print('==================)
    
    
    @staticmethod
    def get_CD_info():
        """Allows user to input new CD into the inventory.
        
        Args:
            None.
        
        Returns:
            cd_id (int): CD ID to add to the database
            cd_title (string): Title of CD to add to the database
            cd_artist (string): Artist of CD to add to the database
            
        """
        cdID = input('Enter ID: ').strip()
        cdTitle = input('What is the CD\'s title? ').strip()
        cdArtist = input('What is the Artist\'s name? ').strip()
        return cdID, cdTitle, cdArtist
    
    @staticmethod
    def get_track_info():
        """Function to request rack info from user to add track to cd
        
        Returns:
            trkID (string): holds the CD ID of the track dataset
            trkTitle (string): holds title of the track
            trkLength (string): holds legth of track
        
        """
        
        trkID = input('Enter position on CD').strip()
        trkTitle = input('Enter track title: ').strip()
        trkLength = input('Enter track length: ').strip()
        return trkID, trkTitle, trkLength
