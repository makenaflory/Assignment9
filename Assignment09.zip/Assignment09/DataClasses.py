#------------------------------------#
# Title: Data Classes
# Desc: A Module for Data Classes
# Change Log: (Who, When, What)
# DBiesinger, 2030-Jan-01, Created File
# DBiesinger, 2030-Jan-02, Modified to add Track class, added methods to CD
# MMezistrano, 2020-Mar-26, Added code, finished todos, added pseudocode comments
#------------------------------------#

if __name__ == '__main__':
    raise Exception('This file is not meant to run by itself')
    
class Track():
    """Stores data about a single track:
        
        properties:
            position: (int) with track position on CD
            title: (str) with track title
            length: (str) with track playtime
            # Error handling in setters will make sure all of these properties are correct!
        methods:
            get_record() -> (str)
    
    """
    # TODOne add Track class code
    # -- Constructor -- #
    def __init__(self, pos, ttl, lgth):
        # -- Attributes -- #
        self.__position = pos
        self.__title = ttl
        self.__length == lgth
    
    # -- Properties -- #
    # Track position
    @property
    def position(self):
        return self.__position
    
    @position.setter
    def position(self, value): #Error handling, makes sure track nubmer is great than 1 and a number
        if type(value) == int:
            if value < 1:
                raise Exception('Position cannot be less than 1')
            self.__position = value
        else:
            raise Exception('Position needs to be an integer.')
    
    #Track title
    @property
    def title(self):
        return self.__title
    
    @title.setter
    def title(self, value):
        if type(value) == str:
            self.__title = value
        else:
            raise Exception('Title needs to be a string')
   
    #Track length
    @property
    def length(self):
        return self.__length
    
    @length.setter
    def length(self, value):
        if type(value) == str:
            self.__length = value
        else:
            raise Exception('Length must be a string.')
    # TODOne Add Track class methods
    # -- Methods -- #
    def __str__(self):
        """ Returns track details in formatted string """
        return '{:>2}. {} ({})'.format(self.position, self.title, self.length)
    
    def get_record(self) -> str:
         """ Returns track record formatted for file """
         return '{},{},{}\n'.format(self.position, self.title, self.length)
    

class CD: # TODOne Modify CD class as required
    """Stores CD/album data:
    
    properties:
        cd_id: (int) with CD ID
        cd_title: (string) with the title of the CD
        cd_artist: (string) with the artist of the CD
        cd_tracks: (list) with track objects of the CD
        # Error handling in setters will make sure this is all correct
    methods:
        get_record() -> (str)
        add_track(track) -> None
        rmv_track(int) -> None
        get_tracks() -> (str)
        get_long_record() -> (str)
    
    """
    # -- Constructor -- #
    def __init__(self, cd_id: int, cd_title: str, cd_artist: str) -> None:
        """Set ID, Title and Artist of a new CD object"""
        # -- Attributes -- #
        try:
            self.__cd_id = int(cd_id)
            self.__cd_title = str(cd_title)
            self.__cd_artist = str(cd_artist)
            self.__tracks = []
        except Exception as e:
            raise Exception('Error setting initial values:\n' + str(e))
       
        # -- Properties -- "
        # CD ID
        @property
        def cd_id(self):
            return self.__cd_id
        
        @cd_id.setter
        def cd_id(self, value):
            try:
                self.__cd_id = int(value)
            except Exception:
                raise Exception('ID needs to be an integer')
        
        # CD title
        @property
        def cd_title(self):
            return self.__cd_title
        
        @cd_title.setter
        def cd_title(self, value):
            try:
                self.__cd_title = str(value)
            except Exception:
                raise Exception('Title needs to be a string')
        
        # CD artist
        @property
        def cd_artist(self):
            return self.__cd_artist
        
        @cd_artist.setter
        def cd_artist(self, value):
            try:
                self.__cd_artist = str(value)
            except Exception:
                raise Exception('Artist needs to be a string')
        
        # CD Tracks
        @property
        def cd_tracks(self):
            return self.__tracks
        
       # -- Methods -- #
        
        def __str__(self):
            """ Returns: CD details as formatted string"""
            return '{:>2}\t{} (by: {})'.format(self.cd_id, self.cd_title, self.cd_artist)
        
        def get_record(self):
            """Returns: CD record formatted for file"""
            return '{},{},{}\n'.format(self.cd_id, self.cd_title, self.cd_artist)
        
        def add_track(self, track: Track) -> None:
            """ Adds a track to the CD
            
            Args: 
                track (Track): Track object to be added to CD
            
            Returns:
                None.
            
            """
            # TODOne append track
            # TODOne sort tracks
            self.__tracks.append(track)
            self.__sort_tracks()
        
        # TODOne remove track
        def rmv_track(self, track_id: int) -> None:
            """Removes the track identified as tracd_id
            
            Args:
                track_id (int): ID of track to be removed
            
            Returns: 
                None
            
            """
            del self.__tracks(track_id - 1)
            self.__sort_tracks()
        
        # TODOne sort tracks
        def __sort_tracks(self):
            """ Sorts tracks using Track.position. Blanks get None"""
            n = len(self.__tracks)
            for track in self.__tracks:
                if (track is not None) and (n < track.position):
                    n = track.position
                tmp_tracks = [None] * n #confused what's going on here
                for track in self.__tracks:
                    if track is not None:
                        tmp_tracks[track.position - 1] = track
                self.__tracks = tmp_tracks
        
        def get_tracks(self) -> str:
            """ Returns string list of tracks saved for Album
            
            Raises:
                Exception: if no tracks are saved.
            
            Returns: 
                result (string): formatted string of tracks
            
            """
            
            self.__sort_tracks()
            if len(self.__tracks) < 1:
                raise Exception('No tracks saved for this album.')
            result = '' # Empty string if error raised
            for track in self.__tracks:
                if track is None: 
                    result += 'No info for this track'
                else:
                    result += str(track) + '\n' # Once track has data it's returned as a string
            return result
        
        def get_long_record(self) -> str:
            """ Gets formatted record of album: Album info plus track details
            
            Returns:
                result (string) formatted info about album and tracks.
                
            """
            
            result = self.get_record() + '\n' #formatted CD record info from previous method
            result += self.get_tracks() +'\n' #formatted track record from previous method
            return result


